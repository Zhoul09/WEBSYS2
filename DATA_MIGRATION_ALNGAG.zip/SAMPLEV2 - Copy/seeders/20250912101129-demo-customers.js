'use strict';

const customers = require('../customers');  
/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Customers', customers, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Customers', {
      email: { [Sequelize.Op.in]: customers.map(c => c.email) }
    }, {});
  }
};

'use strict';

const products = require('../products'); // import the external data file

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Products', products, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Products', {
      name: { [Sequelize.Op.in]: products.map(p => p.name) }
    }, {});
  }
};

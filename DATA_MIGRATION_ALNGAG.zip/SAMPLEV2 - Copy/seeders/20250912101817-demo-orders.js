'use strict';

const orders = require('../orders'); 

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.bulkInsert('Orders', orders, {});
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.bulkDelete('Orders', {
      id: { [Sequelize.Op.in]: orders.map(o => o.id) }
    }, {});
  }
};

const express = require('express')
const router = express.Router();

router.get('/', () => {})
router.get('/college', () => {})
router.get('/college', () => {})

module.exports = router;
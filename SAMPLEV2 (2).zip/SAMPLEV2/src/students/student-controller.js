function getAllStudents() {

}

function getStudentById(req, res) {

}

module.exports = {
    getAllStudents,
    getStudentById,
}